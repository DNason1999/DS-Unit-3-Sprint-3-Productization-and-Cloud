"""ENTRY POINT"""

from .aq_dashboard import create_app

APP = create_app()